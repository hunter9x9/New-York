import React from 'react'

export interface Surgery {
  id: number
  hospital: string
  city: string
  surgeryType: string
  averageCost: number
  rating: number
}

interface Props {
  surgeries: Surgery[]
}

const SurgeryList: React.FC<Props> = ({ surgeries }) => {
  return (
    <table>
      <thead>
        <tr>
          <th>Hospital</th>
          <th>City</th>
          <th>Surgery Type</th>
          <th>Average Cost (USD)</th>
          <th>Rating</th>
        </tr>
      </thead>
      <tbody>
        {surgeries.map(({ id, hospital, city, surgeryType, averageCost, rating }) => (
          <tr key={id}>
            <td>{hospital}</td>
            <td>{city}</td>
            <td>{surgeryType}</td>
            <td>${averageCost.toLocaleString()}</td>
            <td>{rating.toFixed(1)} / 5</td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}

export default SurgeryList
