import React, { useEffect } from 'react'
import L from 'leaflet'

interface Surgery {
  id: number
  hospital: string
  city: string
  lat: number
  lng: number
}

interface Props {
  surgeries: Surgery[]
}

const MapView: React.FC<Props> = ({ surgeries }) => {
  useEffect(() => {
    const map = L.map('map').setView([40.7128, -74.006], 8) // NYC center, zoom 8

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors'
    }).addTo(map)

    surgeries.forEach(s => {
      L.marker([s.lat, s.lng])
        .addTo(map)
        .bindPopup(`<b>${s.hospital}</b><br>${s.city}`)
    })

    return () => {
      map.remove()
    }
  }, [surgeries])

  return <div id="map" className="map"></div>
}

export default MapView
