import React, { useState } from 'react'
import SurgeryList from './components/SurgeryList'
import MapView from './components/MapView'
import nySurgeryData from './data/ny-surgeries.json'

const App: React.FC = () => {
  const [cityFilter, setCityFilter] = useState('')

  const filteredData = cityFilter
    ? nySurgeryData.filter(s => s.city.toLowerCase().includes(cityFilter.toLowerCase()))
    : nySurgeryData

  return (
    <div>
      <h1>Medical Surgery Cost in New York (2025)</h1>
      <p>Compare surgery prices and hospitals in New York State.</p>
      <label>
        Filter by City: {' '}
        <input
          type="text"
          placeholder="Enter city name"
          value={cityFilter}
          onChange={e => setCityFilter(e.target.value)}
        />
      </label>
      <MapView surgeries={filteredData} />
      <SurgeryList surgeries={filteredData} />
    </div>
  )
}

export default App
